<?php

/* themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--photo-credits--section.html.twig */
class __TwigTemplate_093d121fb02b871fe460a8725074c7f28c3589fbc30aa0caafc4834eda55345f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 39, "if" => 40);
        $filters = array("merge" => 41, "trim" => 62, "striptags" => 62, "join" => 72, "raw" => 74);
        $functions = array("include" => 65, "active_theme_path" => 65);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if'),
                array('merge', 'trim', 'striptags', 'join', 'raw'),
                array('include', 'active_theme_path')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 39
        $context["credits"] = array();
        // line 40
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_artist", array()), "value", array()))) {
            // line 41
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_artist", array()), "value", array())));
        }
        // line 43
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_credits_date", array()), "value", array()))) {
            // line 44
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_credits_date", array()), "value", array())));
        }
        // line 46
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_medium", array()), "value", array()))) {
            // line 47
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_medium", array()), "value", array())));
        }
        // line 49
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_dimensions", array()), "value", array()))) {
            // line 50
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_dimensions", array()), "value", array())));
        }
        // line 52
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_location", array()), "value", array()))) {
            // line 53
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_location", array()), "value", array())));
        }
        // line 55
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_copyright", array()), "value", array()))) {
            // line 56
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_copyright", array()), "value", array())));
        }
        // line 58
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_general_credit", array()), "value", array()))) {
            // line 59
            echo "    ";
            $context["credits"] = twig_array_merge((isset($context["credits"]) ? $context["credits"] : null), array(0 => $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_general_credit", array()), "value", array())));
        }
        // line 61
        echo "
";
        // line 62
        if ((( !twig_test_empty((isset($context["credits"]) ? $context["credits"] : null)) ||  !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_image_title", array()), "value", array()))) ||  !twig_test_empty(twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_flexible_wysiwyg_caption", array()), "value", array())))))) {
            // line 63
            echo "    <div class=\"section-hero__figcaption animated delay-600\">
        <a class=\"figcaption-cta js-section-hero__figcaption-cta\">
            <i class=\"icon--small \">";
            // line 65
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-copyright-md.svg"))));
            echo "</i>
            <span>image credit</span>
        </a>
    <div class=\"figcaption js-figcaption--hidden\">
        ";
            // line 69
            if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_image_title", array()), "value", array()))) {
                // line 70
                echo "            <span class=\"title-of-art\"> ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_image_title", array()), "value", array()), "html", null, true));
                echo " </span>
        ";
            }
            // line 72
            echo "        ";
            if ( !twig_test_empty((isset($context["credits"]) ? $context["credits"] : null))) {
                echo " ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["credits"]) ? $context["credits"] : null), " | "), "html", null, true));
                echo " ";
            }
            // line 73
            echo "        ";
            if ( !twig_test_empty(twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_flexible_wysiwyg_caption", array()), "value", array()))))) {
                // line 74
                echo "            ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_flexible_wysiwyg_caption", array()), "value", array())));
                echo "
        ";
            }
            // line 76
            echo "    </div>



    </div>
";
        }
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--photo-credits--section.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 76,  121 => 74,  118 => 73,  111 => 72,  105 => 70,  103 => 69,  96 => 65,  92 => 63,  90 => 62,  87 => 61,  83 => 59,  81 => 58,  77 => 56,  75 => 55,  71 => 53,  69 => 52,  65 => 50,  63 => 49,  59 => 47,  57 => 46,  53 => 44,  51 => 43,  47 => 41,  45 => 40,  43 => 39,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--photo-credits--section.html.twig", "/srv/bindings/2b65e2ed7deb43b986a604bc9ebf730f/code/web/themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--photo-credits--section.html.twig");
    }
}
