<?php

/* themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-plus-md.svg */
class __TwigTemplate_e5cb361b67050a55cc8bd04f5eee6bccc86ca9cc1bc9ea7cef67f27250012cb3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 29 29\"><defs><style>.cls-2{fill:none;stroke-miterlimit:10;stroke-width:1.5px;}</style></defs><polygon points=\"27.44 10.98 18.03 10.98 18.03 1.57 10.97 1.57 10.97 10.98 1.56 10.98 1.56 18.04 10.97 18.04 10.97 27.45 18.03 27.45 18.03 18.04 27.44 18.04 27.44 10.98\"/><polyline class=\"cls-2\" points=\"19.6 29.02 19.6 19.61 29.01 19.61\"/><polyline class=\"cls-2\" points=\"9.4 0 9.4 9.41 -0.01 9.41\"/></svg>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-plus-md.svg";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-plus-md.svg", "/srv/bindings/2b65e2ed7deb43b986a604bc9ebf730f/code/styleguide/src/includes/svg/deyoung/famsf-plus-md.svg");
    }
}
