<?php

/* themes/custom/famsf_digital_stories_theme/svg/famsf-zoom-in-sm.svg */
class __TwigTemplate_b5849bb77e1723606bd213a1be3a9eab11c600043889b428f17d4c49deea8a9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<svg version=\"1.1\" id=\"Layer_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"
   viewBox=\"0 0 16.9 16.9\" style=\"enable-background:new 0 0 16.9 16.9;\" xml:space=\"preserve\">
<path d=\"M11,8.3c-0.3,0-0.6-0.3-0.6-0.6V6.4H9.1c-0.3,0-0.6-0.3-0.6-0.6s0.2-0.6,0.6-0.6h1.3V4c0-0.3,0.2-0.6,0.6-0.6
  s0.6,0.3,0.6,0.6v1.3h1.3c0.3,0,0.6,0.3,0.6,0.6s-0.3,0.6-0.6,0.6h-1.3v1.3C11.6,8.1,11.3,8.3,11,8.3z M16.9,5.9
  c0,1.6-0.6,3-1.7,4.2c-1.1,1.1-2.7,1.7-4.2,1.7c-1.3,0-2.6-0.4-3.6-1.3l-0.8,0.8c0,0.3-0.1,0.7-0.3,0.9l-4.4,4.4
  c-0.4,0.4-1.1,0.4-1.6,0c-0.4-0.4-0.4-1.1,0-1.6l4.4-4.4c0.2-0.2,0.6-0.4,0.9-0.3l0.7-0.7c-0.8-1-1.3-2.3-1.3-3.6
  c0-1.6,0.6-3,1.7-4.2C8,0.6,9.4,0,11,0c1.6,0,3,0.6,4.2,1.7C16.3,2.8,16.9,4.3,16.9,5.9z M15.1,5.9c0-1.1-0.4-2.1-1.2-2.9
  S12.1,1.8,11,1.8C9.9,1.8,8.9,2.2,8.1,3C7.3,3.7,6.9,4.8,6.9,5.9S7.3,8,8.1,8.8c1.6,1.6,4.2,1.6,5.8,0C14.7,8,15.1,7,15.1,5.9z
   M11,3.5\"/>
</svg>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/svg/famsf-zoom-in-sm.svg";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/svg/famsf-zoom-in-sm.svg", "/srv/bindings/32912adea7474e0a8ef9129c4a8efecf/code/styleguide/src/includes/svg/famsf-zoom-in-sm.svg");
    }
}
