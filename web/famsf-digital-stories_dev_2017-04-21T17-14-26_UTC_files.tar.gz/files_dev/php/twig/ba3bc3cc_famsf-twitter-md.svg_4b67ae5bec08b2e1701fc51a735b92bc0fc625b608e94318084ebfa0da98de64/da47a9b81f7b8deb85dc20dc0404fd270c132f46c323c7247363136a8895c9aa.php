<?php

/* themes/custom/famsf_digital_stories_theme/svg/famsf-twitter-md.svg */
class __TwigTemplate_3f535df84e46fdb30230f640b82469929fdfeedbb00b41550ea5f0fb8a239a1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32.3 27\"><path d=\"M21.6,2a5.8,5.8,0,0,1,4.24,1.83,11.69,11.69,0,0,0,3.69-1.41A5.83,5.83,0,0,1,27,5.63a11.61,11.61,0,0,0,3.33-.91,11.73,11.73,0,0,1-2.9,3c0,.25,0,.5,0,.75C27.42,16.15,21.58,25,10.9,25A16.42,16.42,0,0,1,2,22.39a11.78,11.78,0,0,0,1.38.08A11.65,11.65,0,0,0,10.6,20a5.81,5.81,0,0,1-5.42-4,5.94,5.94,0,0,0,1.09.1,5.83,5.83,0,0,0,1.53-.2,5.81,5.81,0,0,1-4.66-5.7v-.07a5.79,5.79,0,0,0,2.63.73A5.81,5.81,0,0,1,4,3.06a16.48,16.48,0,0,0,12,6.07,5.87,5.87,0,0,1-.15-1.32A5.8,5.8,0,0,1,21.6,2m7.93.42h0M21.6,0a7.82,7.82,0,0,0-7.75,6.85A14.55,14.55,0,0,1,5.52,1.8,2,2,0,0,0,4,1.06H3.82a2,2,0,0,0-1.57,1,7.82,7.82,0,0,0-.57,6.67,2,2,0,0,0-.54,1.37v.07a7.81,7.81,0,0,0,2.09,5.31,2,2,0,0,0,0,1.09,7.78,7.78,0,0,0,2.45,3.63,9.85,9.85,0,0,1-3.48.21H2A2,2,0,0,0,.92,24.07,18.45,18.45,0,0,0,10.9,27a18,18,0,0,0,13.77-6.06A19.14,19.14,0,0,0,29.42,8.69,13.67,13.67,0,0,0,32,5.83a2,2,0,0,0-.55-2.77A2,2,0,0,0,29.53.42h-.08a2,2,0,0,0-1,.29,9.68,9.68,0,0,1-2.09.92A7.85,7.85,0,0,0,21.6,0Z\"/></svg>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/svg/famsf-twitter-md.svg";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/svg/famsf-twitter-md.svg", "/srv/bindings/32912adea7474e0a8ef9129c4a8efecf/code/styleguide/src/includes/svg/famsf-twitter-md.svg");
    }
}
