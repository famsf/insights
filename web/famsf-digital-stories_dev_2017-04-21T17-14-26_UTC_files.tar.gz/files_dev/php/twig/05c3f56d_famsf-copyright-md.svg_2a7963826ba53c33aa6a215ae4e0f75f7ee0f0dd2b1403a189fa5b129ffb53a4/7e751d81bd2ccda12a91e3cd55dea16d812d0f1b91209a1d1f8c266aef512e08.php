<?php

/* themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-copyright-md.svg */
class __TwigTemplate_f9cd4599bf5acdc48eeeba8a3aa99ca03cb33b5d8b3408b953a3e7d8e2d27804 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 27 27\"><defs><style>.cls-2{fill:none;stroke-miterlimit:10;stroke-width:1.5px;}</style></defs><path d=\"M14.43,3.39A10.33,10.33,0,1,0,24.75,13.72,10.34,10.34,0,0,0,14.43,3.39ZM12.63,15a2.87,2.87,0,0,0,.33,1,1.85,1.85,0,0,0,.64.66,1.91,1.91,0,0,0,1,.25,2.32,2.32,0,0,0,.72-.11,1.92,1.92,0,0,0,.6-.31,1.43,1.43,0,0,0,.4-.49,1.25,1.25,0,0,0,.12-.64h2.42a3,3,0,0,1-.32,1.44,3.56,3.56,0,0,1-.92,1.15,4.42,4.42,0,0,1-1.35.75,4.86,4.86,0,0,1-1.63.27,5,5,0,0,1-2-.39,4.11,4.11,0,0,1-1.46-1.08,4.65,4.65,0,0,1-.89-1.6,6.32,6.32,0,0,1-.3-2v-.28a6.41,6.41,0,0,1,.3-2,4.55,4.55,0,0,1,.89-1.6,4.21,4.21,0,0,1,1.46-1.08,4.85,4.85,0,0,1,2-.4,5.1,5.1,0,0,1,1.71.28,4,4,0,0,1,1.35.78,3.47,3.47,0,0,1,.88,1.22,3.75,3.75,0,0,1,.3,1.6H16.46a1.68,1.68,0,0,0-.11-.7,1.58,1.58,0,0,0-.38-.57,1.88,1.88,0,0,0-.6-.38,2,2,0,0,0-.77-.14,1.75,1.75,0,0,0-1.64.91,3,3,0,0,0-.33,1,6.21,6.21,0,0,0-.1,1.11v.28A6.66,6.66,0,0,0,12.63,15Z\"/><path class=\"cls-2\" d=\"M14.43,25.89a12.18,12.18,0,0,0,10.1-5.37M18.83,2.36a12.12,12.12,0,0,0-4.4-.82h0A12.19,12.19,0,0,0,2.25,13.72\"/></svg>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-copyright-md.svg";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-copyright-md.svg", "/srv/bindings/2b65e2ed7deb43b986a604bc9ebf730f/code/styleguide/src/includes/svg/deyoung/famsf-copyright-md.svg");
    }
}
