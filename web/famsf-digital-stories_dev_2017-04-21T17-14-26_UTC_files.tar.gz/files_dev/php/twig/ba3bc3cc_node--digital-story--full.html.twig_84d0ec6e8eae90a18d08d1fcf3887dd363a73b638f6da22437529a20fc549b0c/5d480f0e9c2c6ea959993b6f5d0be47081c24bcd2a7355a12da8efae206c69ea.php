<?php

/* themes/custom/famsf_digital_stories_theme/templates/node/node--digital-story--full.html.twig */
class __TwigTemplate_33ac900f417d609350c2dafc147b61400a8700c9a4924de0849665dfdb7d1d5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 70, "if" => 99, "trans" => 110);
        $filters = array("join" => 116, "clean_id" => 148, "trim" => 148, "striptags" => 162, "date" => 266);
        $functions = array("file_url" => 116, "include" => 142, "active_theme_path" => 142);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if', 'trans'),
                array('join', 'clean_id', 'trim', 'striptags', 'date'),
                array('file_url', 'include', 'active_theme_path')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 70
        $context["boldTitle"] = (($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_title_style", array()), "value", array()) == "has-backdrop") || ($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_title_style", array()), "value", array()) == "has-bold-outlined"));
        // line 71
        echo "
";
        // line 72
        $context["classes"] = array(0 => ((        // line 73
(isset($context["logged_in"]) ? $context["logged_in"] : null)) ? ("admin__article") : ("")));
        // line 75
        $context["wrapperClasses"] = array(0 => "site-hero", 1 => (($this->getAttribute($this->getAttribute($this->getAttribute(        // line 77
(isset($context["node"]) ? $context["node"] : null), "field_background_image", array()), "entity", array()), "fileuri", array())) ? ("") : ("pattern")));
        // line 79
        $context["sectionTitleWrapperClasses"] = array(0 => ((        // line 80
(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) ? ("site-hero__title--bold animated") : ("site-hero__title")), 1 => $this->getAttribute($this->getAttribute(        // line 81
(isset($context["node"]) ? $context["node"] : null), "field_title_position", array()), "value", array()), 2 => $this->getAttribute($this->getAttribute(        // line 82
(isset($context["node"]) ? $context["node"] : null), "field_title_style", array()), "value", array()), 3 => "delay-1250");
        // line 85
        $context["sectionHeroClasses"] = array(0 => ((        // line 86
(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) ? ("animated delay-1250") : ("")), 1 => ((($this->getAttribute($this->getAttribute(        // line 87
(isset($context["node"]) ? $context["node"] : null), "field_title_style", array()), "value", array()) != "has-backdrop")) ? ("site-hero__title-text") : ("")));
        // line 89
        $context["sectionTitleClasses"] = array(0 => ((        // line 90
(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) ? ("") : ("animated delay-1500")));
        // line 92
        echo "
";
        // line 93
        $context["animatedClasses"] = array(0 => "animated delay-1500");
        // line 96
        echo "<article";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "addClass", array(0 => (isset($context["classes"]) ? $context["classes"] : null)), "method"), "html", null, true));
        echo ">

    ";
        // line 98
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["title_prefix"]) ? $context["title_prefix"] : null), "html", null, true));
        echo "
    ";
        // line 99
        if ( !(isset($context["page"]) ? $context["page"] : null)) {
            // line 100
            echo "        <h2";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["title_attributes"]) ? $context["title_attributes"] : null), "html", null, true));
            echo ">
            <a href=\"";
            // line 101
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["url"]) ? $context["url"] : null), "html", null, true));
            echo "\" rel=\"bookmark\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["label"]) ? $context["label"] : null), "html", null, true));
            echo "</a>
        </h2>
    ";
        }
        // line 104
        echo "    ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["title_suffix"]) ? $context["title_suffix"] : null), "html", null, true));
        echo "

    ";
        // line 106
        if ((isset($context["display_submitted"]) ? $context["display_submitted"] : null)) {
            // line 107
            echo "        <footer>
            ";
            // line 108
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["author_picture"]) ? $context["author_picture"] : null), "html", null, true));
            echo "
            <div";
            // line 109
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["author_attributes"]) ? $context["author_attributes"] : null), "html", null, true));
            echo ">
                ";
            // line 110
            echo t("Submitted by @author_name on @date", array("@author_name" => (isset($context["author_name"]) ? $context["author_name"] : null), "@date" => (isset($context["date"]) ? $context["date"] : null), ));
            // line 111
            echo "                ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["metadata"]) ? $context["metadata"] : null), "html", null, true));
            echo "
            </div>
        </footer>
    ";
        }
        // line 115
        echo "    <section class=\"js-section pp-scrollable\" id=\"start\">
        <div class=\"";
        // line 116
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["wrapperClasses"]) ? $context["wrapperClasses"] : null), " "), "html", null, true));
        echo "\" ";
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_site_hero_background_image", array()), "value", array()))) {
            echo "data-bg=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, call_user_func_array($this->env->getFunction('file_url')->getCallable(), array($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_site_hero_background_image", array()), "entity", array()), "fileuri", array()))), "html", null, true));
            echo "\" ";
        }
        echo ">
            <div class=\"";
        // line 117
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleWrapperClasses"]) ? $context["sectionTitleWrapperClasses"] : null), " "), "html", null, true));
        echo "\">
                ";
        // line 118
        if ((isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
            // line 119
            echo "                    <div class=\"delay-3500 animated animated-border--top\"></div>
                ";
        }
        // line 121
        echo "                <div class=\"js-section-hero--get_height ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionHeroClasses"]) ? $context["sectionHeroClasses"] : null), " "), "html", null, true));
        echo "\">

                    ";
        // line 123
        if ((is_string($__internal_be76de2a69494ba56e739c770110e1d82c49a16570c20d9149c83ad2fe9e1cd2 = $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_theme", array()), "value", array())) && is_string($__internal_62fa1fd303da412122ad985a609fb022110f378a31eecacf2694301e823017b9 = "legion") && ('' === $__internal_62fa1fd303da412122ad985a609fb022110f378a31eecacf2694301e823017b9 || 0 === strpos($__internal_be76de2a69494ba56e739c770110e1d82c49a16570c20d9149c83ad2fe9e1cd2, $__internal_62fa1fd303da412122ad985a609fb022110f378a31eecacf2694301e823017b9)))) {
            // line 124
            echo "                    <span class=\"site-hero__logo ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["animatedClasses"]) ? $context["animatedClasses"] : null), " "), "html", null, true));
            echo "\"><a href=\"https://legionofhonor.famsf.org/\" >Legion of Honor Museum</a></span>
                    ";
        } else {
            // line 126
            echo "                    <span class=\"site-hero__logo ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["animatedClasses"]) ? $context["animatedClasses"] : null), " "), "html", null, true));
            echo "\"><a href=\"https://deyoung.famsf.org/\" >de Young Museum</a></span>
                    ";
        }
        // line 128
        echo "                    <h1 class=\"";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleClasses"]) ? $context["sectionTitleClasses"] : null), " "), "html", null, true));
        echo "\"> ";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["label"]) ? $context["label"] : null), "html", null, true));
        echo "</h1>
                    <h2 class=\"";
        // line 129
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleClasses"]) ? $context["sectionTitleClasses"] : null), " "), "html", null, true));
        echo "\">";
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_exhibition_dates", array()), "value", array()), "html", null, true));
        echo "</h2>
                </div>
                ";
        // line 131
        if ( !(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
            // line 132
            echo "                <div class=\"site-hero__rectangle top animated fadeInLeft delay-250 js-section-hero--set_height\"></div>
                <div class=\"site-hero__rectangle bottom animated fadeInRight delay-250 js-section-hero--set_height\"></div>
                ";
        }
        // line 135
        echo "                ";
        if ((isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
            // line 136
            echo "                    <div class=\"delay-3500 animated animated-border--bottom\"></div>
                ";
        }
        // line 138
        echo "            </div>
        </div>
        <button class=\"js-next-page next-page animated delay-100\">
            <div class=\"icon--xsmall\">
                ";
        // line 142
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-caret-down-sm.svg"))));
        echo "
            </div>
        next page
        </button>
    </section>
    ";
        // line 147
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_section", array()), "html", null, true));
        echo "
    <section class=\"js-section pp-scrollable footer\" id=\"";
        // line 148
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, \Drupal\Component\Utility\Html::getId(twig_trim_filter($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_footer_title", array()), "value", array()))), "html", null, true));
        echo "\">
        <footer class=\"card-section\">
            <div class=\"container\">
                <div class=\"l-1up\">
                    <h2>";
        // line 152
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_footer_title", array()), "value", array()), "html", null, true));
        echo "</h2>
                </div>
            </div>
            <div class=\"container\">

                <div class=\"l-33-66--1\">
                    <article class=\"footer-section\">
                        ";
        // line 159
        if ( !twig_test_empty($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_main_footer_image", array()), "entity", array()), "fileuri", array()))) {
            // line 160
            echo "                            <img data-src=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, call_user_func_array($this->env->getFunction('file_url')->getCallable(), array($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_main_footer_image", array()), "entity", array()), "fileuri", array()))), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_main_footer_image", array()), "entity", array()), "alt", array()), "html", null, true));
            echo "\">
                        ";
        }
        // line 162
        echo "                        ";
        if ( !twig_test_empty(twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_non_member_ticket_link", array()), "uri", array()))))) {
            // line 163
            echo "                            <a class=\"color-block-button--full\" href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_non_member_ticket_link", array()), "uri", array()), "html", null, true));
            echo "\">Non-member Tickets</a>
                        ";
        }
        // line 165
        echo "                        ";
        if ( !twig_test_empty(twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_member_ticket_link", array()), "uri", array()))))) {
            // line 166
            echo "                            <a class=\"color-block-button--full\" href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_member_ticket_link", array()), "uri", array()), "html", null, true));
            echo "\">Member Tickets</a>
                        ";
        }
        // line 168
        echo "                    </article>
                </div>

                <div class=\"l-33-66--2\">
                    ";
        // line 172
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_footer_feature", array()), "html", null, true));
        echo "
                </div>
            </div>

            <div class=\"container\">

                <div class=\"l-2up--1\">
                    <h3 class=\"footer-section__title\">Visiting</h3>
                    ";
        // line 180
        if ((is_string($__internal_72c932617e1389a4a36c1b539d95efd00a1db10bd8d0de9866f894758ef3692d = $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_theme", array()), "value", array())) && is_string($__internal_4b6472b2dfb79848b5475d970dea95023db3acfa7103eee2469f5e4b2f116800 = "legion") && ('' === $__internal_4b6472b2dfb79848b5475d970dea95023db3acfa7103eee2469f5e4b2f116800 || 0 === strpos($__internal_72c932617e1389a4a36c1b539d95efd00a1db10bd8d0de9866f894758ef3692d, $__internal_4b6472b2dfb79848b5475d970dea95023db3acfa7103eee2469f5e4b2f116800)))) {
            // line 181
            echo "                    <img class=\"footer-img__half\" data-src=\"/";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath(), "html", null, true));
            echo "/imgs/footer/visiting.png\" alt=\"Guests spend time in the courtyard at the Legion of Honor\" />
                    <div class=\"footer-block__half\">
                        <h4>Legion of Honor </h4>
                        <p>Lincoln Park, 100 34th Avenue, San Francisco<br />Open 9:30 a.m.– 5:15 p.m.<br />Tuesdays–Sundays.<br />415 750-3600</p>

                        <p>
                            <a class=\"footer-link\" href=\"https://www.famsf.org/\">Fine Arts Museums of San Francisco</a>
                            <br />
                            <a class=\"footer-link\" href=\"https://deyoung.famsf.org/\">de Young</a>
                            <br />
                            <a class=\"footer-link\" href=\"https://legionofhonor.famsf.org/\">Legion of Honor</a>
                        </p>
                    </div>
                    <!-- Legion follow links -->
                    <h4>Follow Us</h4>
                    <ul class=\"social-media\">
                        <li class=\"social-media__item\">
                            <a href=\"https://www.facebook.com/LegionofHonor/\"><span>Facebook</span><i class=\"icon--small\">";
            // line 198
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-facebook-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"https://twitter.com/legionofhonor\"><span>Twitter</span><i class=\"icon--small\">";
            // line 201
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-twitter-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"https://www.instagram.com/legionofhonor/\"><span>Instagram</span><i class=\"icon--small\">";
            // line 204
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-instagram-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"http://legionofhonormuseum.tumblr.com/\"><span>Tumblr</span><i class=\"icon--small\">";
            // line 207
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-tumblr-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"http://www.youtube.com/famsf\"><span>Youtube</span><i class=\"icon--small\">";
            // line 210
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-youtube-md.svg"))));
            echo "</i></a>
                        </li>
                    </ul>
                ";
        } else {
            // line 214
            echo "                    <img class=\"footer-img__half\" data-src=\"/";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath(), "html", null, true));
            echo "/imgs/footer/visiting.jpg\" alt=\"Guests spend time in the courtyard at the de Young\" />
                    <div class=\"footer-block__half\">
                        <h4>de Young Museum </h4>
                        <p>Golden Gate Park, 50 Hagiwara Tea Garden Drive, San Francisco, CA 94118<br />Open 9:30 a.m.– 5:15 p.m.<br />Tuesdays–Sundays.<br />415 750-3600</p>

                        <p>
                            <a class=\"footer-link\" href=\"https://www.famsf.org/\">Fine Arts Museums of San Francisco</a>
                            <br />
                            <a class=\"footer-link\" href=\"https://deyoung.famsf.org/\">de Young</a>
                            <br />
                            <a class=\"footer-link\" href=\"https://legionofhonor.famsf.org/\">Legion of Honor</a>
                        </p>
                    </div>
                    <!-- de Young follow links -->
                    <h4>Follow Us</h4>
                    <ul class=\"social-media\">
                        <li class=\"social-media__item\">
                            <a href=\"https://www.facebook.com/deYoungMuseum/\"><span>Facebook</span><i class=\"icon--small\">";
            // line 231
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-facebook-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"https://twitter.com/deyoungmuseum\"><span>Twitter</span><i class=\"icon--small\">";
            // line 234
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-twitter-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"https://www.instagram.com/deyoungmuseum/\"><span>Instagram</span><i class=\"icon--small\">";
            // line 237
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-instagram-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"http://deyoungmuseum.tumblr.com/\"><span>Tumblr</span><i class=\"icon--small\">";
            // line 240
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-tumblr-md.svg"))));
            echo "</i></a>
                        </li>
                        <li class=\"social-media__item\">
                            <a href=\"https://www.youtube.com/user/FAMSF\"><span>Youtube</span><i class=\"icon--small\">";
            // line 243
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/famsf-youtube-md.svg"))));
            echo "</i></a>
                        </li>
                    </ul>
                ";
        }
        // line 247
        echo "                </div>
                <div class=\"l-2up--2\">
                    <h3 class=\"footer-section__title\">Special Thanks</h3>
                    ";
        // line 250
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_sponsor", array()), "html", null, true));
        echo "
                </div>
            </div>
            <div class=\"container footer-small\">
                <div class=\"l-2up--1\">
                    ";
        // line 255
        if ((is_string($__internal_4d6a5482abb31bfdbcebdaf6b4336a8f92b464bb28378a5d88d9c71a7632eabd = $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_theme", array()), "value", array())) && is_string($__internal_b034556350ef2b805decd11345ee8dceffee148b02f6c9bfca4a72ce1c3a4589 = "legion") && ('' === $__internal_b034556350ef2b805decd11345ee8dceffee148b02f6c9bfca4a72ce1c3a4589 || 0 === strpos($__internal_4d6a5482abb31bfdbcebdaf6b4336a8f92b464bb28378a5d88d9c71a7632eabd, $__internal_b034556350ef2b805decd11345ee8dceffee148b02f6c9bfca4a72ce1c3a4589)))) {
            // line 256
            echo "                    <a href=\"https://legionofhonor.famsf.org/contact\">Contact</a>
                    <a href=\"https://legionofhonor.famsf.org/privacy\">Privacy</a>
                    <a href=\"https://legionofhonor.famsf.org/terms\">Terms &amp; Conditions</a>
                    ";
        } else {
            // line 260
            echo "                    <a href=\"https://deyoung.famsf.org/contact\">Contact</a>
                    <a href=\"https://deyoung.famsf.org/privacy\">Privacy</a>
                    <a href=\"https://deyoung.famsf.org/terms\">Terms &amp; Conditions</a>
                    ";
        }
        // line 264
        echo "                </div>
                <div class=\"l-2up--2\">
                    <p class=\"footer-small__copyright\">&copy;";
        // line 266
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true));
        echo " Fine Arts Museums of San Francisco</p>
                </div>
            </div>
        </footer>
    </section>
</article>
<div class=\"zoom-overlay-background js-zoom-overlay-background\" style=\"display: none;\">
</div>
<div class=\"zoom-window js-zoom-window\" style=\"display: none;\">
    <button class=\"zoom-close js-zoom-close\" href=\"#\" style=\"display: none;\">
        <i class=\"icon--small\">
            ";
        // line 277
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-zoom-out-sm.svg"))));
        echo "
        </i>
        <div class=\"zoom-marker__text\">close</div>
    </button>
    <div class=\"zoom-window__content js-zoom-window__content\" style=\"display: none;\">
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/templates/node/node--digital-story--full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  427 => 277,  413 => 266,  409 => 264,  403 => 260,  397 => 256,  395 => 255,  387 => 250,  382 => 247,  375 => 243,  369 => 240,  363 => 237,  357 => 234,  351 => 231,  330 => 214,  323 => 210,  317 => 207,  311 => 204,  305 => 201,  299 => 198,  278 => 181,  276 => 180,  265 => 172,  259 => 168,  253 => 166,  250 => 165,  244 => 163,  241 => 162,  233 => 160,  231 => 159,  221 => 152,  214 => 148,  210 => 147,  202 => 142,  196 => 138,  192 => 136,  189 => 135,  184 => 132,  182 => 131,  175 => 129,  168 => 128,  162 => 126,  156 => 124,  154 => 123,  148 => 121,  144 => 119,  142 => 118,  138 => 117,  128 => 116,  125 => 115,  117 => 111,  115 => 110,  111 => 109,  107 => 108,  104 => 107,  102 => 106,  96 => 104,  88 => 101,  83 => 100,  81 => 99,  77 => 98,  71 => 96,  69 => 93,  66 => 92,  64 => 90,  63 => 89,  61 => 87,  60 => 86,  59 => 85,  57 => 82,  56 => 81,  55 => 80,  54 => 79,  52 => 77,  51 => 75,  49 => 73,  48 => 72,  45 => 71,  43 => 70,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/templates/node/node--digital-story--full.html.twig", "/srv/bindings/32912adea7474e0a8ef9129c4a8efecf/code/web/themes/custom/famsf_digital_stories_theme/templates/node/node--digital-story--full.html.twig");
    }
}
