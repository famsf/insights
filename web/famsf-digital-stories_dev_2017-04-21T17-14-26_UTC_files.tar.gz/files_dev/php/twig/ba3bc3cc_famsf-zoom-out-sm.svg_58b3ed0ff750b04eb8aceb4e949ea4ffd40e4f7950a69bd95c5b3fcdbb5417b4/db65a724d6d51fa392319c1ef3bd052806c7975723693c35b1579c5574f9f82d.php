<?php

/* themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-zoom-out-sm.svg */
class __TwigTemplate_593d7c27ee0271d99ad4878579de2f402b608fcff15f56e6950d7df399933955 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 16.89 16.89\"><defs><style>.cls-2{fill:none;stroke-miterlimit:10;stroke-width:1px;}</style></defs><path class=\"cls-1\" d=\"M12.63,6.19H9.26a.5.5,0,0,0,0,1h3.38a.5.5,0,1,0,0-1Zm1.88-3.06A5,5,0,0,0,7,9.79l-.86.86a1,1,0,0,0-.82.29l-4,4a1,1,0,1,0,1.43,1.43l4-4A1,1,0,0,0,7,11.55l.86-.86a5,5,0,0,0,6.66-7.56Zm-.75,6.39a4,4,0,0,1-5.63,0h0a4,4,0,1,1,5.63,0Z\"/><path class=\"cls-2\" d=\"M15.29,2.35A6.11,6.11,0,0,0,10.95.55h0a6.15,6.15,0,0,0-5.42,9M8,12.12A6.15,6.15,0,0,0,15.29,11\"/></svg>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-zoom-out-sm.svg";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/svg/deyoung/famsf-zoom-out-sm.svg", "/srv/bindings/32912adea7474e0a8ef9129c4a8efecf/code/styleguide/src/includes/svg/deyoung/famsf-zoom-out-sm.svg");
    }
}
