<?php

/* themes/custom/famsf_digital_stories_theme/templates/page/page--digital-story.html.twig */
class __TwigTemplate_15e8fd5c00cb7c6e8a71ff868b2109184353932bc9b872e6ef8114a1d679ca30 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("for" => 73, "set" => 74, "if" => 84);
        $filters = array("clean_id" => 74, "trim" => 74, "striptags" => 94);
        $functions = array("include" => 51, "active_theme_path" => 51, "file_url" => 87);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('for', 'set', 'if'),
                array('clean_id', 'trim', 'striptags'),
                array('include', 'active_theme_path', 'file_url')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 39
        echo "
";
        // line 40
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "main_nav", array()), "html", null, true));
        echo "

<div class=\"js-loading loading\">
  <div class=\"loader\">
    <div class=\"ball\"></div>
    <div class=\"ball\"></div>
    <div class=\"ball\"></div>
    <div class=\"ball\"></div>
  </div>
</div>
<a href=\"#\" class=\"dashboard-toggle js-dashboard-toggle js-closed button-with-icon\">
  <i class=\"icon--med\">";
        // line 51
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-hamburger-md.svg"))));
        echo "</i>
  <i class=\"icon--small\">";
        // line 52
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-hamburger-sm.svg"))));
        echo "</i>
</a>
<div class=\"dashboard js-dashboard js-closed\">
  <nav>
    <div class=\"dashboard-header\">
      <div class=\"container\">
        <div class=\"l-1up\">
          <a href=\"#\" class=\"dashboard-close js-dashboard-close button-with-icon\">
            <div>Close</div>
            <i class=\"icon--med\">";
        // line 61
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-close-md.svg"))));
        echo "</i>
            <i class=\"icon--small\">";
        // line 62
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-close-sm.svg"))));
        echo "</i>
          </a>
        </div>
      </div>
    </div>

    <div class=\"container\">
      <div class=\"l-1up\">

        <ul class=\"dashboard__nav-list\" id=\"myMenu\">
          <li class=\"dashboard__nav-item active\" data-menuanchor=\"start\"><a href=\"#start\">Start</a></li>
          ";
        // line 73
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sectionTitles"]) ? $context["sectionTitles"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 74
            echo "          ";
            $context["sectionId"] = \Drupal\Component\Utility\Html::getId(twig_trim_filter($context["section"]));
            // line 75
            echo "          <li class=\"dashboard__nav-item\" data-menuanchor=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["sectionId"]) ? $context["sectionId"] : null), "html", null, true));
            echo "\"><a href=\"#";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["sectionId"]) ? $context["sectionId"] : null), "html", null, true));
            echo "\">";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $context["section"], "html", null, true));
            echo "</a></li>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "        </ul>
      </div>
    </div>
  </nav>
  <section class=\"dashboard-section\">
    <div class=\"container\">
      <div class=\"l-2up\">
        ";
        // line 84
        if ( !twig_test_empty($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_store_item_link", array()), "uri", array()))) {
            // line 85
            echo "        <a class=\"footer-link\" href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_store_item_link", array()), "uri", array()), "html", null, true));
            echo "\">
          ";
            // line 86
            if ( !twig_test_empty($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_store_item_photo", array()), "entity", array()), "fileuri", array()))) {
                // line 87
                echo "          <img data-src=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, call_user_func_array($this->env->getFunction('file_url')->getCallable(), array($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_store_item_photo", array()), "entity", array()), "fileuri", array()))), "html", null, true));
                echo "\" alt=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_store_item_photo", array()), "entity", array()), "alt", array()), "html", null, true));
                echo "\">
          ";
            }
            // line 89
            echo "          ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_store_item_title", array()), "value", array()), "html", null, true));
            echo "
        </a>
        ";
        }
        // line 92
        echo "      </div>
      <div class=\"l-2up\">
        ";
        // line 94
        if ( !twig_test_empty(twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_non_member_ticket_link", array()), "uri", array()))))) {
            // line 95
            echo "        <a class=\"color-block-button--full\" href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_non_member_ticket_link", array()), "uri", array()), "html", null, true));
            echo "\">Non-member Tickets</a>
        ";
        }
        // line 97
        echo "        ";
        if ( !twig_test_empty(twig_trim_filter(strip_tags($this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_member_ticket_link", array()), "uri", array()))))) {
            // line 98
            echo "        <a class=\"color-block-button--full\" href=\"";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["node"]) ? $context["node"] : null), "field_member_ticket_link", array()), "uri", array()), "html", null, true));
            echo "\">Member Tickets</a>
        ";
        }
        // line 100
        echo "      </div>
    </div>
  </section>

</div>
<div class=\"dashboard-overlay-background js-dashboard-overlay-background\" style=\"display: none;\"></div>
<main role=\"main\" class=\"digital-story js-pagepiling\">

  <a id=\"main-content\" tabindex=\"-1\"></a>";
        // line 109
        echo "
  ";
        // line 110
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array()), "html", null, true));
        echo "

</main>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/templates/page/page--digital-story.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 110,  178 => 109,  168 => 100,  162 => 98,  159 => 97,  153 => 95,  151 => 94,  147 => 92,  140 => 89,  132 => 87,  130 => 86,  125 => 85,  123 => 84,  114 => 77,  101 => 75,  98 => 74,  94 => 73,  80 => 62,  76 => 61,  64 => 52,  60 => 51,  46 => 40,  43 => 39,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/templates/page/page--digital-story.html.twig", "/srv/bindings/2b65e2ed7deb43b986a604bc9ebf730f/code/web/themes/custom/famsf_digital_stories_theme/templates/page/page--digital-story.html.twig");
    }
}
