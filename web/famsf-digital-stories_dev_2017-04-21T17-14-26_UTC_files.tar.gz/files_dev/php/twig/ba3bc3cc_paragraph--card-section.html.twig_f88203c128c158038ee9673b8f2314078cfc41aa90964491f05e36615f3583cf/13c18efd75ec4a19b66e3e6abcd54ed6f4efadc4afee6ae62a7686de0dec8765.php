<?php

/* themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--card-section.html.twig */
class __TwigTemplate_79c75711ab3d77896b7b8ec3798f3539436d18194ad1a646f2f5cc330010fa48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("set" => 39, "if" => 65);
        $filters = array("striptags" => 42, "render" => 42, "clean_class" => 44, "clean_id" => 47, "trim" => 47, "join" => 74);
        $functions = array("file_url" => 94, "include" => 119, "active_theme_path" => 119, "url" => 124);

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('set', 'if'),
                array('striptags', 'render', 'clean_class', 'clean_id', 'trim', 'join'),
                array('file_url', 'include', 'active_theme_path', 'url')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 39
        $context["boldTitle"] = (($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_section_title_style", array()), "value", array()) == "has-backdrop") || ($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_section_title_style", array()), "value", array()) == "has-bold-outlined"));
        // line 40
        $context["classes"] = array(0 => "js-section", 1 => (((strip_tags($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute(        // line 42
(isset($context["content"]) ? $context["content"] : null), "field_scrollable", array()))) == 1)) ? ("pp-scrollable") : ("")), 2 => "paragraph", 3 => ("paragraph--type--" . \Drupal\Component\Utility\Html::getClass($this->getAttribute(        // line 44
(isset($context["paragraph"]) ? $context["paragraph"] : null), "bundle", array()))), 4 => ((        // line 45
(isset($context["view_mode"]) ? $context["view_mode"] : null)) ? (("paragraph--view-mode--" . \Drupal\Component\Utility\Html::getClass((isset($context["view_mode"]) ? $context["view_mode"] : null)))) : ("")));
        // line 47
        $context["containerId"] = \Drupal\Component\Utility\Html::getId(twig_trim_filter($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_card_section_title", array()), "value", array())));
        // line 48
        $context["wrapperClasses"] = array(0 => "section-hero__wrapper", 1 => (($this->getAttribute($this->getAttribute($this->getAttribute(        // line 50
(isset($context["paragraph"]) ? $context["paragraph"] : null), "field_background_image", array()), "entity", array()), "fileuri", array())) ? ("") : ("pattern")));
        // line 52
        $context["sectionTitleWrapperClasses"] = array(0 => ((        // line 53
(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) ? ("section-hero__title--bold animated") : ("section-hero__title")), 1 => $this->getAttribute($this->getAttribute(        // line 54
(isset($context["paragraph"]) ? $context["paragraph"] : null), "field_section_title_position", array()), "value", array()), 2 => $this->getAttribute($this->getAttribute(        // line 55
(isset($context["paragraph"]) ? $context["paragraph"] : null), "field_section_title_style", array()), "value", array()), 3 => ((($this->getAttribute($this->getAttribute(        // line 56
(isset($context["paragraph"]) ? $context["paragraph"] : null), "field_section_title_style", array()), "value", array()) == "has-backdrop")) ? ("delay-1250") : ("")));
        // line 58
        $context["sectionTitleClasses"] = array(0 => "animated", 1 => ((        // line 60
(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) ? ("delay-1250") : ("delay-1500")), 2 => "js-section-hero--get_height");
        // line 63
        echo "
<section";
        // line 64
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "addClass", array(0 => (isset($context["classes"]) ? $context["classes"] : null)), "method"), "setAttribute", array(0 => "id", 1 => (isset($context["containerId"]) ? $context["containerId"] : null)), "method"), "html", null, true));
        echo ">
    ";
        // line 65
        if (($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_display_hero_section", array()), "value", array()) == 1)) {
            // line 66
            echo "
        ";
            // line 67
            if ( !twig_test_empty($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_video_source_paragraph", array())))) {
                // line 68
                echo "        <div class=\"section-hero\">
            <div class=\"section-hero__video-wrapper ";
                // line 69
                if (twig_test_empty($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_photo_credits", array())))) {
                    // line 70
                    echo "                no-caption
                ";
                }
                // line 71
                echo "\">
                ";
                // line 72
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_video_source_paragraph", array()), "html", null, true));
                echo "
                <div class=\"section-hero__wrapper has-video\">
                    <div class=\"";
                // line 74
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleWrapperClasses"]) ? $context["sectionTitleWrapperClasses"] : null), " "), "html", null, true));
                echo "\">
                        ";
                // line 75
                if ((isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
                    // line 76
                    echo "                        <div class=\"delay-2500 animated animated-border--top\"></div>
                        ";
                }
                // line 78
                echo "                        <h1 class=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleClasses"]) ? $context["sectionTitleClasses"] : null), " "), "html", null, true));
                echo "\">";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_card_section_title", array()), "value", array()), "html", null, true));
                echo "</h1>
                        ";
                // line 79
                if (($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_section_title_style", array()), "value", array()) != "has-dotted-border")) {
                    // line 80
                    echo "                        <div class=\"section-hero__rectangle top animated fadeInLeft delay-250 js-section-hero--set_height\"></div>
                        <div class=\"section-hero__rectangle bottom animated fadeInRight delay-250 js-section-hero--set_height\"></div>
                        ";
                }
                // line 83
                echo "                        ";
                if ((isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
                    // line 84
                    echo "                            <div class=\"delay-2500 animated animated-border--bottom\"></div>
                        ";
                }
                // line 86
                echo "                    </div>
                </div>
            </div>
            ";
                // line 89
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_photo_credits", array()), "html", null, true));
                echo "
        </div>

        ";
            } else {
                // line 93
                echo "        <div class=\"section-hero\">
            <div class=\"";
                // line 94
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["wrapperClasses"]) ? $context["wrapperClasses"] : null), " "), "html", null, true));
                echo "\" ";
                if ( !twig_test_empty($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_background_image", array()), "entity", array()), "fileuri", array()))) {
                    echo "data-bg=\"";
                    echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, call_user_func_array($this->env->getFunction('file_url')->getCallable(), array($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_background_image", array()), "entity", array()), "fileuri", array()))), "html", null, true));
                    echo "\"";
                }
                echo ">
                <div class=\"";
                // line 95
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleWrapperClasses"]) ? $context["sectionTitleWrapperClasses"] : null), " "), "html", null, true));
                echo "\">
                    ";
                // line 96
                if ((isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
                    // line 97
                    echo "                    <div class=\"delay-2500 animated animated-border--top\"></div>
                    ";
                }
                // line 99
                echo "                    <h1 class=\"";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, twig_join_filter((isset($context["sectionTitleClasses"]) ? $context["sectionTitleClasses"] : null), " "), "html", null, true));
                echo "\">";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_card_section_title", array()), "value", array()), "html", null, true));
                echo "</h1>
                    ";
                // line 100
                if ( !(isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
                    // line 101
                    echo "                    <div class=\"section-hero__rectangle top animated fadeInLeft delay-250 js-section-hero--set_height\"></div>
                    <div class=\"section-hero__rectangle bottom animated fadeInRight delay-250 js-section-hero--set_height\"></div>
                    ";
                }
                // line 104
                echo "                    ";
                if ((isset($context["boldTitle"]) ? $context["boldTitle"] : null)) {
                    // line 105
                    echo "                        <div class=\"delay-2500 animated animated-border--bottom\"></div>
                    ";
                }
                // line 107
                echo "                </div>
            </div>
            ";
                // line 109
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_photo_credits", array()), "html", null, true));
                echo "
        </div>
        ";
            }
            // line 112
            echo "    ";
        }
        // line 113
        echo "
    ";
        // line 114
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "field_sections_in_card", array()), "html", null, true));
        echo "

    ";
        // line 116
        if (($this->getAttribute($this->getAttribute((isset($context["paragraph"]) ? $context["paragraph"] : null), "field_display_share_widget", array()), "value", array()) == 1)) {
            // line 117
            echo "        <div class=\"js-share\">
            <button class=\"share-button js-share-button button-with-icon animated delay-500\">
                <i class=\"icon--small\">";
            // line 119
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-share-sm.svg"))));
            echo "
                </i>
                <div>share</div>
            </button>
            <div class=\"share-expander js-share-expander js-share-expander--is-closed\">
                <div class=\"addthis_inline_share_toolbox\" data-url=\"";
            // line 124
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getUrl("<current>")));
            echo "#";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, (isset($context["containerId"]) ? $context["containerId"] : null), "html", null, true));
            echo "\"></div>
            </div>
        </div>
    ";
        }
        // line 128
        echo "    <button class=\"js-next-page next-page animated delay-100\">
        <div class=\"icon--xsmall\">";
        // line 129
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(twig_include($this->env, $context, ((($this->env->getExtension('Drupal\Core\Template\TwigExtension')->getActiveThemePath() . "/svg/") . (isset($context["custom_theme"]) ? $context["custom_theme"] : null)) . "/famsf-caret-down-sm.svg"))));
        echo "</div>
        next page
    </button>
</section>
";
    }

    public function getTemplateName()
    {
        return "themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--card-section.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 129,  226 => 128,  217 => 124,  209 => 119,  205 => 117,  203 => 116,  198 => 114,  195 => 113,  192 => 112,  186 => 109,  182 => 107,  178 => 105,  175 => 104,  170 => 101,  168 => 100,  161 => 99,  157 => 97,  155 => 96,  151 => 95,  141 => 94,  138 => 93,  131 => 89,  126 => 86,  122 => 84,  119 => 83,  114 => 80,  112 => 79,  105 => 78,  101 => 76,  99 => 75,  95 => 74,  90 => 72,  87 => 71,  83 => 70,  81 => 69,  78 => 68,  76 => 67,  73 => 66,  71 => 65,  67 => 64,  64 => 63,  62 => 60,  61 => 58,  59 => 56,  58 => 55,  57 => 54,  56 => 53,  55 => 52,  53 => 50,  52 => 48,  50 => 47,  48 => 45,  47 => 44,  46 => 42,  45 => 40,  43 => 39,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--card-section.html.twig", "/srv/bindings/32912adea7474e0a8ef9129c4a8efecf/code/web/themes/custom/famsf_digital_stories_theme/templates/paragraph/paragraph--card-section.html.twig");
    }
}
